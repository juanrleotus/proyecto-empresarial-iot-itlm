# Domótica ITLM — App Android

App nativa en Kotlin que reemplaza a la versión de MIT App Inventor.
Monitorea los sensores, comanda los actuadores y muestra la cámara.

---

## Abrir el proyecto

1. Android Studio → **File → Open**
2. Elegir la carpeta `DomoticaITLM` (la que contiene `settings.gradle.kts`)
3. Esperar el *Gradle Sync*. La primera vez descarga dependencias, tarda unos minutos.
4. Si avisa que falta el *Gradle Wrapper*, aceptar que lo genere.

Requisitos: Android Studio Ladybug o posterior, JDK 17 (viene incluido).

## Antes de probar

- El celular tiene que estar en **la misma red WiFi** que el broker y las placas.
- Escribir la IP del broker en el campo de arriba y tocar **CONECTAR**.
- No usar `localhost`: esa dirección apunta al propio celular.

---

## Estructura

| Archivo | Qué hace |
|---|---|
| `Topicos.kt` | Todos los tópicos MQTT en un solo lugar |
| `MqttManager.kt` | Cliente MQTT: conectar, suscribir, publicar |
| `MainActivity.kt` | Interfaz y lógica de la pantalla |
| `activity_main.xml` | Diseño de la pantalla |

Para cambiar un tópico se toca **únicamente** `Topicos.kt`.

---

## Decisiones técnicas

**Paho Java, no Paho Android Service.** La librería `org.eclipse.paho.android.service`
está sin mantenimiento y falla en las versiones nuevas de Android. Se usa el cliente
Java puro (`mqttv3`), que corre en su propio hilo y devuelve los avisos al hilo
principal con un `Handler`.

**Tráfico sin cifrar habilitado.** Desde Android 9 el HTTP sin TLS está bloqueado
por defecto. Como el broker (1883) y la ESP32-CAM (80 y 81) no usan TLS, hace falta
`network_security_config.xml`. En una app de producción esto no iría: se usaría
MQTT sobre TLS en el 8883.

**Los botones se pintan al tocarlos y además escuchan el estado real.** El color
cambia en el acto para que la respuesta sea inmediata, pero cuando llega el mensaje
retenido de la placa, ese valor manda. Si la placa está apagada, el botón se corrige
solo en cuanto reconecta.

**El estado ESPERA.** El aire acondicionado tiene tres estados, no dos: cuando se
pide encenderlo antes de que se cumpla el tiempo mínimo de reposo del compresor,
la placa responde `ESPERA` y el botón se pone naranja.

**La IP de la cámara no se escribe a mano.** La ESP32-CAM publica su propia dirección
en `empresa/camara/estado` de forma retenida, y la app la toma de ahí. Si el router
le asigna otra IP, la app se adapta sola.

---

## Tópicos

| Función | Tópico | Sentido |
|---|---|---|
| Temperatura planta | `empresa/planta/temperatura` | placa → app |
| Temperatura oficina | `empresa/oficina/temperatura` | placa → app |
| Temperatura almacén | `empresa/almacen/temperatura` | placa → app |
| Temperatura tanque | `empresa/tanque/temperatura` | placa → app |
| Aire | `empresa/planta/aire/cmd` · `/estado` | app → placa · placa → app |
| Luces | `empresa/oficina/luces/cmd` · `/estado` | app → placa · placa → app |
| Bomba | `empresa/tanque/rele/cmd` · `/estado` | app → placa · placa → app |
| Cámara | `empresa/camara/cmd` · `/estado` · `/evento` | comandos, URLs y fotos |

Comandos de la cámara: `FOTO`, `FLASH_ON`, `FLASH_OFF`, `STATUS`.

---

## Si algo no anda

| Síntoma | Causa probable |
|---|---|
| Queda en "Conectando..." | IP equivocada, o celular en otra red |
| "No se pudo conectar" | Mosquitto apagado, o firewall bloqueando el 1883 |
| Conecta pero no llegan datos | Tópicos distintos entre firmware y `Topicos.kt` |
| Los botones quedan grises | No llega el estado retenido: esa placa no está en el broker |
| La foto no aparece | La cámara no pudo capturar; probar `http://IP_CAM/capture` en el navegador |
| El video queda en blanco | Revisar que `empresa/camara/estado` traiga la clave `pagina` |
