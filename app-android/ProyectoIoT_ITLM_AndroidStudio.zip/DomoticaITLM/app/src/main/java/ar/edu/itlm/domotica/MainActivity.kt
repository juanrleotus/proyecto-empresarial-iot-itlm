package ar.edu.itlm.domotica

import android.annotation.SuppressLint
import android.graphics.Color
import android.os.Bundle
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Button
import android.widget.EditText
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import coil.load
import org.json.JSONObject

class MainActivity : AppCompatActivity() {

    // ── Vistas ──
    private lateinit var etIpBroker: EditText
    private lateinit var btnConectar: Button
    private lateinit var tvEstado: TextView

    private lateinit var tvPlanta: TextView
    private lateinit var tvOficina: TextView
    private lateinit var tvAlmacen: TextView
    private lateinit var tvTanque: TextView

    private lateinit var btnAire: Button
    private lateinit var btnLuces: Button
    private lateinit var btnBomba: Button
    private lateinit var btnFoto: Button
    private lateinit var btnFlash: Button
    private lateinit var btnVideo: Button

    private lateinit var ivFoto: ImageView
    private lateinit var wvVideo: WebView

    private lateinit var mqtt: MqttManager

    // ── Estado de cada actuador: "ON" | "OFF" | "ESPERA" | "" ──
    private var estadoAire = ""
    private var estadoLuces = ""
    private var estadoBomba = ""
    private var estadoFlash = ""

    /** URL de la pagina de video, que publica la propia camara. */
    private var urlPaginaCamara = ""

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        enlazarVistas()
        configurarWebView()

        mqtt = MqttManager(
            onEstadoCambiado = { conectado, detalle -> mostrarEstado(conectado, detalle) },
            onMensaje = { topico, mensaje -> procesarMensaje(topico, mensaje) }
        )

        btnConectar.setOnClickListener {
            val ip = etIpBroker.text.toString().trim()
            if (ip.isEmpty()) {
                Toast.makeText(this, "Escribí la IP del broker", Toast.LENGTH_SHORT).show()
            } else {
                mqtt.conectar(ip)
            }
        }

        // ── Actuadores con estado ──
        // Se pinta el boton en el acto para que la respuesta sea inmediata,
        // y despues el estado real que publica la placa lo confirma o lo
        // corrige. Asi el boton nunca queda mostrando algo falso por mucho
        // tiempo si la placa no respondio.
        btnAire.setOnClickListener {
            val nuevo = if (estadoAire == "ON") "OFF" else "ON"
            estadoAire = nuevo
            pintarBoton(btnAire, "AIRE", nuevo)
            mqtt.publicar(Topicos.AIRE_CMD, nuevo)
        }

        btnLuces.setOnClickListener {
            val nuevo = if (estadoLuces == "ON") "OFF" else "ON"
            estadoLuces = nuevo
            pintarBoton(btnLuces, "LUCES", nuevo)
            mqtt.publicar(Topicos.LUCES_CMD, nuevo)
        }

        btnBomba.setOnClickListener {
            val nuevo = if (estadoBomba == "ON") "OFF" else "ON"
            estadoBomba = nuevo
            pintarBoton(btnBomba, "BOMBA", nuevo)
            mqtt.publicar(Topicos.BOMBA_CMD, nuevo)
        }

        btnFlash.setOnClickListener {
            val nuevo = if (estadoFlash == "ON") "OFF" else "ON"
            estadoFlash = nuevo
            pintarBoton(btnFlash, "FLASH", nuevo)
            mqtt.publicar(Topicos.CAMARA_CMD, if (nuevo == "ON") "FLASH_ON" else "FLASH_OFF")
        }

        // ── Foto: es una accion puntual, no tiene estado ON/OFF ──
        btnFoto.setOnClickListener {
            mqtt.publicar(Topicos.CAMARA_CMD, "FOTO")
            Toast.makeText(this, "Foto solicitada...", Toast.LENGTH_SHORT).show()
        }

        btnVideo.setOnClickListener {
            if (urlPaginaCamara.isEmpty()) {
                Toast.makeText(
                    this,
                    "Todavía no llegó la dirección de la cámara",
                    Toast.LENGTH_LONG
                ).show()
            } else {
                wvVideo.loadUrl(urlPaginaCamara)
            }
        }
    }

    private fun enlazarVistas() {
        etIpBroker = findViewById(R.id.etIpBroker)
        btnConectar = findViewById(R.id.btnConectar)
        tvEstado = findViewById(R.id.tvEstado)

        tvPlanta = findViewById(R.id.tvPlanta)
        tvOficina = findViewById(R.id.tvOficina)
        tvAlmacen = findViewById(R.id.tvAlmacen)
        tvTanque = findViewById(R.id.tvTanque)

        btnAire = findViewById(R.id.btnAire)
        btnLuces = findViewById(R.id.btnLuces)
        btnBomba = findViewById(R.id.btnBomba)
        btnFoto = findViewById(R.id.btnFoto)
        btnFlash = findViewById(R.id.btnFlash)
        btnVideo = findViewById(R.id.btnVideo)

        ivFoto = findViewById(R.id.ivFoto)
        wvVideo = findViewById(R.id.wvVideo)
    }

    @SuppressLint("SetJavaScriptEnabled")
    private fun configurarWebView() {
        wvVideo.settings.javaScriptEnabled = true   // la pagina de la camara usa JS
        wvVideo.settings.loadWithOverviewMode = true
        wvVideo.settings.useWideViewPort = true
        wvVideo.webViewClient = WebViewClient()      // abrir dentro de la app
    }

    // ════════════════════════════════════════════════════════
    //   RECEPCION DE MENSAJES MQTT
    // ════════════════════════════════════════════════════════
    private fun procesarMensaje(topico: String, mensaje: String) {
        when (topico) {
            // ── Sensores ──
            Topicos.PLANTA_TEMP  -> tvPlanta.text  = formatearMedicion(mensaje)
            Topicos.OFICINA_TEMP -> tvOficina.text = formatearMedicion(mensaje)
            Topicos.ALMACEN_TEMP -> tvAlmacen.text = formatearMedicion(mensaje)
            Topicos.TANQUE_TEMP  -> tvTanque.text  = formatearMedicion(mensaje)

            // ── Estados confirmados por las placas ──
            Topicos.AIRE_ESTADO -> {
                estadoAire = leerValor(mensaje)
                pintarBoton(btnAire, "AIRE", estadoAire)
            }
            Topicos.LUCES_ESTADO -> {
                estadoLuces = leerValor(mensaje)
                pintarBoton(btnLuces, "LUCES", estadoLuces)
            }
            Topicos.BOMBA_ESTADO -> {
                estadoBomba = leerValor(mensaje)
                pintarBoton(btnBomba, "BOMBA", estadoBomba)
            }

            // ── Camara ──
            Topicos.CAMARA_ESTADO -> {
                val json = aJson(mensaje)
                urlPaginaCamara = json?.optString("pagina", "") ?: ""
                estadoFlash = json?.optString("flash", "") ?: ""
                pintarBoton(btnFlash, "FLASH", estadoFlash)
            }

            Topicos.CAMARA_EVENTO -> {
                val url = aJson(mensaje)?.optString("url", "") ?: ""
                if (url.isNotEmpty()) {
                    // El "?t=" que agrega la camara evita que Android
                    // muestre la foto anterior guardada en cache.
                    ivFoto.load(url)
                }
            }
        }
    }

    /**
     * Las placas publican {"v":24.8,"u":"C","ts":...}.
     * Si alguna todavia manda el valor suelto, igual se muestra.
     */
    private fun formatearMedicion(mensaje: String): String {
        val json = aJson(mensaje) ?: return mensaje.trim()
        val valor = json.opt("v")?.toString() ?: "—"
        val unidad = json.optString("u", "")
        return if (unidad.isEmpty()) valor else "$valor $unidad"
    }

    private fun leerValor(mensaje: String): String {
        val json = aJson(mensaje) ?: return mensaje.trim().uppercase()
        return json.optString("v", "").uppercase()
    }

    private fun aJson(texto: String): JSONObject? = try {
        JSONObject(texto)
    } catch (e: Exception) {
        null   // no era JSON: se trata como texto plano
    }

    // ════════════════════════════════════════════════════════
    //   INTERFAZ
    // ════════════════════════════════════════════════════════
    private fun pintarBoton(boton: Button, nombre: String, estado: String) {
        val color = when (estado) {
            "ON"     -> R.color.verde_on
            "OFF"    -> R.color.rojo_off
            "ESPERA" -> R.color.naranja_espera   // compresor en reposo
            else     -> R.color.gris_sin_dato
        }
        boton.backgroundTintList = ContextCompat.getColorStateList(this, color)
        boton.setTextColor(Color.WHITE)
        boton.text = "$nombre\n${if (estado.isEmpty()) "—" else estado}"
    }

    private fun mostrarEstado(conectado: Boolean, detalle: String) {
        tvEstado.text = detalle
        tvEstado.setBackgroundColor(
            ContextCompat.getColor(
                this,
                if (conectado) R.color.verde_on else R.color.rojo_off
            )
        )
        btnConectar.text = if (conectado) "RECONECTAR" else "CONECTAR"
    }

    override fun onDestroy() {
        super.onDestroy()
        mqtt.desconectar()
    }
}
