package ar.edu.itlm.domotica

import android.os.Handler
import android.os.Looper
import org.eclipse.paho.client.mqttv3.IMqttDeliveryToken
import org.eclipse.paho.client.mqttv3.MqttAsyncClient
import org.eclipse.paho.client.mqttv3.MqttCallback
import org.eclipse.paho.client.mqttv3.MqttConnectOptions
import org.eclipse.paho.client.mqttv3.MqttMessage
import org.eclipse.paho.client.mqttv3.persist.MemoryPersistence

/**
 * Envoltorio del cliente MQTT de Eclipse Paho.
 *
 * Se usa la version Java pura (mqttv3) y NO el "Paho Android Service",
 * que esta sin mantenimiento y da problemas en las versiones nuevas de
 * Android. El cliente corre en su propio hilo; los avisos a la interfaz
 * se devuelven siempre por el hilo principal.
 */
class MqttManager(
    private val onEstadoCambiado: (conectado: Boolean, detalle: String) -> Unit,
    private val onMensaje: (topico: String, mensaje: String) -> Unit
) {

    private var cliente: MqttAsyncClient? = null
    private val hiloPrincipal = Handler(Looper.getMainLooper())

    /** Para que dos celulares nunca usen el mismo identificador. */
    private val clientId = "AndroidITLM_" + System.currentTimeMillis().toString(16)

    fun conectar(ip: String, puerto: Int = 1883) {
        desconectar()

        try {
            val servidor = "tcp://$ip:$puerto"
            val c = MqttAsyncClient(servidor, clientId, MemoryPersistence())

            c.setCallback(object : MqttCallback {
                override fun connectionLost(causa: Throwable?) {
                    avisarEstado(false, "Conexión perdida: ${causa?.message ?: "sin detalle"}")
                }

                override fun messageArrived(topico: String, mensaje: MqttMessage) {
                    val texto = String(mensaje.payload)
                    hiloPrincipal.post { onMensaje(topico, texto) }
                }

                override fun deliveryComplete(token: IMqttDeliveryToken?) { /* no se usa */ }
            })

            val opciones = MqttConnectOptions().apply {
                isCleanSession = true
                connectionTimeout = 10
                keepAliveInterval = 60
                isAutomaticReconnect = true
            }

            avisarEstado(false, "Conectando a $ip...")

            c.connect(opciones, null, object : org.eclipse.paho.client.mqttv3.IMqttActionListener {
                override fun onSuccess(token: org.eclipse.paho.client.mqttv3.IMqttToken?) {
                    // Al conectar, suscribirse a todo. Los estados de los
                    // actuadores se publican retenidos, asi que el broker
                    // entrega el ultimo valor conocido en el acto.
                    Topicos.SUSCRIPCIONES.forEach { t ->
                        try { c.subscribe(t, 0) } catch (e: Exception) { /* ignorar */ }
                    }
                    avisarEstado(true, "Conectado a $ip")
                }

                override fun onFailure(
                    token: org.eclipse.paho.client.mqttv3.IMqttToken?,
                    excepcion: Throwable?
                ) {
                    avisarEstado(false, "No se pudo conectar: ${excepcion?.message ?: "error"}")
                }
            })

            cliente = c

        } catch (e: Exception) {
            avisarEstado(false, "Error: ${e.message}")
        }
    }

    /** Publica un comando. Los comandos NO van retenidos: son eventos puntuales. */
    fun publicar(topico: String, mensaje: String) {
        val c = cliente
        if (c == null || !c.isConnected) {
            avisarEstado(false, "Sin conexión: no se pudo enviar")
            return
        }
        try {
            c.publish(topico, MqttMessage(mensaje.toByteArray()).apply {
                qos = 0
                isRetained = false
            })
        } catch (e: Exception) {
            avisarEstado(false, "Error al publicar: ${e.message}")
        }
    }

    fun estaConectado(): Boolean = cliente?.isConnected == true

    fun desconectar() {
        try {
            cliente?.let { if (it.isConnected) it.disconnect() }
            cliente?.close()
        } catch (e: Exception) { /* ignorar */ }
        cliente = null
    }

    private fun avisarEstado(conectado: Boolean, detalle: String) {
        hiloPrincipal.post { onEstadoCambiado(conectado, detalle) }
    }
}
