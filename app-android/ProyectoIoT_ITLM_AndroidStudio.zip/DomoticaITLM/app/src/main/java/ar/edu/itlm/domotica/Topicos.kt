package ar.edu.itlm.domotica

/**
 * Todos los topicos MQTT del sistema, en un solo lugar.
 *
 * Tienen que coincidir LETRA POR LETRA con los del firmware de cada
 * placa. Si alguno no coincide, la app publica o escucha al vacio
 * sin dar ningun error.
 */
object Topicos {

    // ── Sensores (placa -> app) ──
    const val PLANTA_TEMP  = "empresa/planta/temperatura"
    const val OFICINA_TEMP = "empresa/oficina/temperatura"
    const val ALMACEN_TEMP = "empresa/almacen/temperatura"
    const val TANQUE_TEMP  = "empresa/tanque/temperatura"

    // ── Aire acondicionado (ESP32 - planta) ──
    const val AIRE_CMD    = "empresa/planta/aire/cmd"
    const val AIRE_ESTADO = "empresa/planta/aire/estado"

    // ── Luces (ESP32-S3 - oficina) ──
    const val LUCES_CMD    = "empresa/oficina/luces/cmd"
    const val LUCES_ESTADO = "empresa/oficina/luces/estado"

    // ── Bomba (ESP8266 - tanque) ──
    const val BOMBA_CMD    = "empresa/tanque/rele/cmd"
    const val BOMBA_ESTADO = "empresa/tanque/rele/estado"

    // ── Camara (ESP32-CAM - almacen) ──
    const val CAMARA_CMD    = "empresa/camara/cmd"
    const val CAMARA_ESTADO = "empresa/camara/estado"
    const val CAMARA_EVENTO = "empresa/camara/evento"

    /** Todo lo que la app necesita escuchar al conectarse. */
    val SUSCRIPCIONES = arrayOf(
        PLANTA_TEMP, OFICINA_TEMP, ALMACEN_TEMP, TANQUE_TEMP,
        AIRE_ESTADO, LUCES_ESTADO, BOMBA_ESTADO,
        CAMARA_ESTADO, CAMARA_EVENTO
    )
}
